
/*

Rachel Bittar 
301006074

*/


/* 1 ===================================================================================================*/


create or replace PROCEDURE DDPROJ_SP
    (idProj_in IN DD_Project.idProj%TYPE,
     ddProject_out OUT DD_Project%ROWTYPE)
IS
BEGIN
    DBMS_OUTPUT.PUT_LINE('DDPROJ Procedure called');
    SELECT IDPROJ ,PROJNAME ,PROJSTARTDATE ,PROJENDDATE ,PROJFUNDGOAL ,PROJCOORD   INTO ddProject_out
    FROM DD_Project
    WHERE idProj= idProj_in;
    DBMS_OUTPUT.PUT_LINE('Name  =>  ' || ddProject_out.Projname);
    DBMS_OUTPUT.PUT_LINE('Start Date  => ' || ddProject_out.Projstartdate);
    DBMS_OUTPUT.PUT_LINE('End Date  =>  ' || ddProject_out.Projenddate);
    DBMS_OUTPUT.PUT_LINE('Fund Goal => ' || ddProject_out.Projfundgoal);
    DBMS_OUTPUT.PUT_LINE('Coordinator => ' || ddProject_out.ProjCoord);
END;

SET SERVEROUTPUT ON;
  DECLARE
  SP_TEST DD_PROJECT%ROWTYPE;
BEGIN
DDPROJ_SP(501, SP_TEST);
END;

/* 2 ===================================================================================================*/


CREATE OR REPLACE PROCEDURE DDPAY_SP
     (donor_id IN NUMBER,
      active_pl OUT BOOLEAN)
  IS
      pay_count NUMBER;
      result varchar2(255);
  BEGIN
      SELECT COUNT(*)
         INTO pay_count
         FROM dd_pledge 
         WHERE iddonor = donor_id AND idstatus = 10 AND paymonths > 1;
      IF pay_count > 1 THEN
         active_pl := TRUE;
      ELSE active_pl := FALSE;
END IF;

DBMS_OUTPUT.PUT_LINE('Active Pledge and paymonths => ' || CASE active_pl WHEN TRUE THEN 'true' ELSE 'false' END);

END;
/*Test with Anonymous Block*/
SET SERVEROUTPUT ON;
  DECLARE
    test BOOLEAN;
    BEGIN
    DDPAY_SP(305,test);
END;


/*3 ===================================================================================================*/

CREATE OR REPLACE PROCEDURE ddckpay_sp
  (p_id IN dd_pledge.idpledge%TYPE,
   p_amt IN dd_pledge.pledgeamt%TYPE)
  IS
    lv_pay_num dd_pledge.pledgeamt%TYPE;
BEGIN
  SELECT pledgeamt/paymonths
    INTO lv_pay_num
    FROM dd_pledge
    WHERE idpledge = p_id
      AND paymonths > 0;
  IF p_amt <> lv_pay_num THEN
    RAISE_APPLICATION_ERROR(-20050, 'Incorrect  payment amount => ' ||
                            ' planned payment => ' || lv_pay_num);
    END IF;
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    DBMS_OUTPUT.PUT_LINE('No payment information');
END;

BEGIN
  ddckpay_sp(101,25);
END;

/*4 ===================================================================================================*/


create or replace PROCEDURE DDCXBAL_SP
    (idPledge_in IN DD_Pledge.idPledge%TYPE,
     PledgeAmt_out OUT DD_Pledge.PledgeAmt%TYPE,
     PayAmt_out OUT NUMBER,
     Balance_out OUT DD_Payment.PayAmt%TYPE)
IS 
BEGIN  
       SELECT Distinct PledgeAmt, PayAmt,  PledgeAmt-PayAmt
        INTO PledgeAmt_out, PayAmt_out, Balance_out 
        FROM DD_Pledge INNER JOIN DD_Payment USING(idPledge)
        WHERE idPledge=idPledge_in AND PledgeAmt-PayAmt>0;
    DBMS_OUTPUT.PUT_LINE('Pledge Amount: ' ||PledgeAmt_out);
    DBMS_OUTPUT.PUT_LINE('Pay Amount: ' ||PayAmt_out);
    DBMS_OUTPUT.PUT_LINE('Balance: ' ||Balance_out);
END;


SET SERVEROUTPUT ON;
  DECLARE
     SP_PLEDGEAMOUNT  DD_Pledge.idPledge%TYPE;
     SP_PAYMENTTOTAL NUMBER(6,2);
     SP_B DD_Payment.PayAmt%TYPE;
    BEGIN
     DDCXBAL_SP(108, SP_PLEDGEAMOUNT, SP_PAYMENTTOTAL, SP_B);
END;


