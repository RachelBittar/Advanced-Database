/*
Rachel Bittar 301006074
Assignment 2
*/

/*Question 1*


Question 1
CREATE TABLE called supplier  with the following fields . 
supplier_id numeric(10)  - > Primary key with constraint name 
supplier_name varchar2(50) - >unique name 
contact_name varchar2(50)
phone_no varchar2(10)- >unique name
city varchar2(10) 
Region –> should accept only  ('N', 'NW', 'NE', 'S', 'SE', 'SW', 'W', 'E')
*/

drop table supplier;

CREATE TABLE supplier (
supplier_id NUMBER(10) NOT NULL,
supplier_name VARCHAR2(50) UNIQUE,
contact_name VARCHAR2(50),
phone_no VARCHAR2(10) UNIQUE,
city VARCHAR2(10),
region VARCHAR2(2) NOT NULL CHECK (region='N' OR region= 'NW' OR region='NE' OR region='S' OR region='SE' OR region='SW' OR region='W'OR region='E'),
CONSTRAINT PK_Supplier PRIMARY KEY (supplier_id) 
);


/*Add values
1.  Insert 5 records
*/
INSERT INTO supplier
VALUES (1, 'New Orleans Cajun Delights', 'Shelley Burke', '1005554822', 'Toronto', 'N' );

INSERT INTO supplier
VALUES (2, 'Specialty Biscuits', 'Ian Devling', '2002584822', 'Manchester', 'SE' );

INSERT INTO supplier
VALUES (555, 'Rachel Buttini', 'Name Giudici', '3512584822', 'Florida', 'SW' );

INSERT INTO supplier
VALUES (4, 'Samsung', 'Cameron Diaz', '3502584350', 'Vancouver', 'NE' );

INSERT INTO supplier
VALUES (5, 'Siltronic AG', 'Tom Hanks', '4162584822', 'Montreal', 'E' );


/*
2.  Display the details of the supplier who comes from Florida and their supplier id 500;
*/
SELECT *
FROM supplier
WHERE SUPPLIER_ID>500 and city= 'Florida';

/*
3.  Add phone number in the supplier table using DDL command
*/
ALTER TABLE supplier
ADD phone_number VARCHAR2(10) UNIQUE;

/*
4.  Delete the unused column in the supplier table 
*/
ALTER TABLE supplier
DROP COLUMN contact_name;

/*
5.  Write a sql command to delete supplier table.
*/
DROP TABLE supplier;

/*
6.  Create a view named supplier_contact . Include supplier_id,supplier_name,phone_no  
*/

drop view supplier_contact
CREATE VIEW supplier_contact
AS SELECT supplier_id, supplier_name, phone_no  
FROM supplier;

/********************************************Question 2*****************************************

Ecommerce site determines shipping cost based on the products ordered and membership. The valid rates are displayed in the following table:

  QUANTITY
REGULAR SHIPPING COST
MEMBERS SHIPPING COST 
Up to 3
$ 8.00
$ 4.00
4-6
$7.00
$ 3.50
7-10
$10.00
$5.00
>10
$15.00
$7.50

1.  Create a flowchart to outline the processing steps in order to handle this calculation. 
2.  Create a pl/sql block to complete the above task. Include variable that holds Y OR N to include membership status and a variable to denote the number of items purchased. Verify with different values 

*/
 SET SERVEROUTPUT ON
 
 DECLARE 
  lv_membership BOOLEAN := false;
  lv_number NUMBER(2) := 10;
  lv_price NUMBER(5,2) := 0;
  
 BEGIN
   CASE
     WHEN lv_membership THEN
      IF (lv_number <= 3) THEN  
          lv_price := 4.0;
        ELSIF (lv_number >= 4 AND lv_number <= 6) THEN
          lv_price := 3.50;
        ELSIF (lv_number >= 7 AND lv_number <= 10) THEN
          lv_price := 5.0;
        ELSE
          lv_price := 7.50;
        END IF;     
          DBMS_OUTPUT.PUT_LINE('Membership - The final is:'|| lv_price);
      
    ELSE
      IF (lv_number <= 3) THEN  
          lv_price := 8.0;
        ELSIF (lv_number >= 4 AND lv_number <= 6) THEN
          lv_price:= 7.0;
        ELSIF (lv_number >= 7 AND lv_number <= 10) THEN
          lv_price:= 10.0;
        ELSE
          lv_price := 15.0;
        END IF;
          DBMS_OUTPUT.PUT_LINE('Not a membership - The price is not:'|| lv_price);
        END CASE;       
        
END;

/**************************************************Question 3******************************


Run below script to create the table
DROP TABLE messages;
CREATE TABLE messages (results NUMBER(3));

a) Insert the numbers 1 through 10, excluding 6 and 8. 
b) Commit before the end of the block. 
c) Execute a SELECT statement to verify that your PL/SQL block worked


*/

drop table MESSAGES;
create table MESSAGES (results number(3));

BEGIN 
  FOR COUNTER IN 1..10 LOOP
    IF 
      COUNTER NOT IN (6,8)
    THEN
      INSERT INTO MESSAGES(results) values(counter);
    END IF;
  END LOOP;
  
  COMMIT;
END;

 select *
 from messages;

