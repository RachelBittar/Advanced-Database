/*
Rachel Bittar 301006074
Assignment 2
*/

/*Question 1*/

drop table supplier;

CREATE TABLE supplier (
supplier_id NUMBER(10) NOT NULL,
supplier_name VARCHAR2(50) UNIQUE,
contact_name VARCHAR2(50),
phone_no VARCHAR2(10) UNIQUE,
city VARCHAR2(10),
region VARCHAR2(2) NOT NULL CHECK (region='N' OR region= 'NW' OR region='NE' OR region='S' OR region='SE' OR region='SW' OR region='W'OR region='E'),
CONSTRAINT PK_Supplier PRIMARY KEY (supplier_id) 
);


/*Add values
Question  1 -> a
*/
INSERT INTO supplier
VALUES (1, 'New Orleans Cajun Delights', 'Shelley Burke', '1005554822', 'Toronto', 'N' );

INSERT INTO supplier
VALUES (2, 'Specialty Biscuits', 'Ian Devling', '2002584822', 'Manchester', 'SE' );

INSERT INTO supplier
VALUES (555, 'Rachel Buttini', 'Name Giudici', '3512584822', 'Florida', 'SW' );

INSERT INTO supplier
VALUES (4, 'Samsung', 'Cameron Diaz', '3502584350', 'Vancouver', 'NE' );

INSERT INTO supplier
VALUES (5, 'Siltronic AG', 'Tom Hanks', '4162584822', 'Montreal', 'E' );


/*Question 1
get date -> b
*/
SELECT *
FROM supplier
WHERE SUPPLIER_ID>500 and city= 'Florida';

/*Question 1
Add number -> c
*/
ALTER TABLE supplier
ADD phone_number VARCHAR2(10) UNIQUE;

ALTER TABLE supplier
DROP COLUMN contact_name;

/*delete tabl
-> d 
*/
DROP TABLE supplier;

/*
Create view
-> e
*/

drop view supplier_contact
CREATE VIEW supplier_contact
AS SELECT supplier_id, supplier_name, phone_no  
FROM supplier;

/********************************************Question 2******************************************/
 SET SERVEROUTPUT ON
 
 DECLARE 
  lv_membership BOOLEAN := false;
  lv_number NUMBER(2) := 10;
  lv_price NUMBER(5,2) := 0;
  
 BEGIN
   CASE
     WHEN lv_membership THEN
      IF (lv_number <= 3) THEN  
          lv_price := 4.0;
        ELSIF (lv_number >= 4 AND lv_number <= 6) THEN
          lv_price := 3.50;
        ELSIF (lv_number >= 7 AND lv_number <= 10) THEN
          lv_price := 5.0;
        ELSE
          lv_price := 7.50;
        END IF;     
          DBMS_OUTPUT.PUT_LINE('Membership - The final is:'|| lv_price);
      
    ELSE
      IF (lv_number <= 3) THEN  
          lv_price := 8.0;
        ELSIF (lv_number >= 4 AND lv_number <= 6) THEN
          lv_price:= 7.0;
        ELSIF (lv_number >= 7 AND lv_number <= 10) THEN
          lv_price:= 10.0;
        ELSE
          lv_price := 15.0;
        END IF;
          DBMS_OUTPUT.PUT_LINE('Not a membership - The price is not:'|| lv_price);
        END CASE;       
        
END;

/**************************************************Question 3*******************************/

drop table MESSAGES;
create table MESSAGES (results number(3));

BEGIN 
  FOR COUNTER IN 1..10 LOOP
    IF 
      COUNTER NOT IN (6,8)
    THEN
      INSERT INTO MESSAGES(results) values(counter);
    END IF;
  END LOOP;
  
  COMMIT;
END;

 select *
 from messages;

